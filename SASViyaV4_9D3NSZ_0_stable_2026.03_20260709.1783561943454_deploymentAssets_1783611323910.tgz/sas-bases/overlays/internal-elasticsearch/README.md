---
category: OpenSearch
tocprty: 20
---

# Configure an Internal OpenSearch Instance for the SAS Viya Platform

**Note:** SAS terminology standards prohibit the use of the term "master." However, this document refers to the term "master node" to maintain alignment with OpenSearch documentation.

**Note:** In previous releases, the SAS Viya platform included OpenDistro for Elasticsearch. Many Kubernetes resources keep the name OpenDistro for backwards compatiblity. 

This README file describes the files used to customize an internally managed instance of OpenSearch using the sas-opendistro operator provided by SAS. 

## Instructions

In order to use the internal search cluster instance, you must customize your
deployment to point to the required overlay and transformers.

1. Go to the base kustomization.yaml file (`$deploy/kustomization.yaml`). In the
   resources block of that file, add the following content, including adding
   the block if it does not already exist.

   ```yaml
   resources:
   ...
   - sas-bases/overlays/internal-elasticsearch
   ...
   ```

2. Go to the base kustomization.yaml file (`$deploy/kustomization.yaml`). In the
   transformers block of that file, add the following content, including adding
   the block if it does not already exist.

   ```yaml
   transformers:
   ...
   - sas-bases/overlays/internal-elasticsearch/internal-elasticsearch-transformer.yaml
   ...
   ```

3. Deploying OpenSearch requires configuration to support the ability to create many memory mapped areas if `vm.max_map_count` is set too low. 

   Several methods are available to configure the sysctl option `vm.max_map_count` documented below. Choose a method which is supported for your platform.

   | Method | Platforms | Requirements |
   | ------ | --------- | ------------ |
   | Apply sysctl configuration manually | All platforms | Ability to configure sysctl on stateful Kubernetes nodes |
   | Use sas-opendistro-sysctl init container | Microsoft Azure Kubernetes Service (AKS) without Microsoft Defender<br/>Amazon Elastic Kubernetes Service (EKS) <br/>Google Kubernetes Engine (GKE)<br/>RedHat Openshift<br/> | Privileged Containers<br/>Allow Privilege Escalation<br/> |
   | Use sas-opendistro-sysctl DaemonSet | Microsoft Azure Kubernetes Service (AKS) with Microsoft Defender | Privileged Containers<br/>Allow Privilege Escalation<br/>Kubernetes nodes for stateful workloads labeled with `workload.sas.com/class` as `stateful` |
   | Disable mmap support | All platforms | Unable to apply sysctl configuration manually or use privileged containers |

* **Apply sysctl configuration manually**: The Kubernetes administrator should set the `vm.max_map_count` property to be at least 262144 for stateful workload nodes.

This is recommended if your deployment does not support privileged containers.

If you are using a managed Kubernetes cluster, your cloud provider probably provisions the nodes dynamically. In this instance, be aware that manual modifications do not persist after a restart of a Kubernetes node. The cluster administrator must use an alternative method to save the vm.max_map_count setting.

* **Use sas-opendistro-sysctl init container**: If your deployment allows privileged containers, add a reference to `sas-bases/overlays/internal-elasticsearch/sysctl-transformer.yaml` to the transformers block of the base kustomization.yaml. The `sysctl-transformer.yaml` transformer must be included before the `sas-bases/overlays/required/transformers.yaml` transformer. Here is an example:

   ```yaml
   transformers:
   - sas-bases/overlays/internal-elasticsearch/sysctl-transformer.yaml
   - sas-bases/overlays/required/transformers.yaml
   ```

Using the sysctl-transformer.yaml file is not secure-by-default. If you use the sysctl-transformer.yaml file, you must accept a small degree of risk. The init container must be run at a privileged level since it modifies the kernel parameters of the host. The container terminates after it sets the kernel parameter. The OpenSearch software then starts as a non-privileged container.

* **Use sas-opendistro-sysctl DaemonSet** (Microsoft Azure Kubernetes Service with Microsoft Defender only): If your deployment allows privileged containers and you are deploying to an environment secured by Microsoft Defender, add a reference to `sas-bases/overlays/internal-elasticsearch/sysctl-daemonset.yaml` to the resources block of the base kustomization file. Here is an example:

   ```yaml
   resources:
   - sas-bases/overlays/internal-elasticsearch/sysctl-daemonset.yaml
   ```

* **Disable mmap support**: If your deployment does not allow privileged containers and you are in an environment where you cannot control the memory map settings, add a reference to `sas-bases/overlays/internal-elasticsearch/disable-mmap-transformer.yaml` to the transformers block of the base kustomization.yaml to disable memory mapping instead. The `disable-mmap-transformer.yaml` transformer must be included before the `sas-bases/overlays/required/transformers.yaml`. Here is an example:

   ```yaml
   transformers:
   - sas-bases/overlays/internal-elasticsearch/disable-mmap-transformer.yaml
   - sas-bases/overlays/required/transformers.yaml
   ```

   Disabling memory mapping is discouraged since doing so will negatively impact performance and may result in out of memory exceptions. 

4. The SAS Viya platform supports deployments in a FIPS-compliant environment. In order to configure OpenSearch to run in a FIPS-compliant environment, you must apply a transformer to your deployment manifest.

* **Configure OpenSearch for FIPS compliance**: Add a reference to `sas-bases/overlays/internal-elasticsearch/configure-opensearch-fips-transformer.yaml` to the transformers block of the base kustomization.yaml. The `configure-opensearch-fips-transformer.yaml` transformer must be included before the `sas-bases/overlays/required/transformers.yaml`. Here is an example:

   ```yaml
   transformers:
   - sas-bases/overlays/internal-elasticsearch/configure-opensearch-fips-transformer.yaml
   - sas-bases/overlays/required/transformers.yaml
   ```
   Customers who want to deploy with FIPS-enabled nodes should verify that supporting third-party components have been FIPS-validated. For example, builds of cert-manager that are available for a standard download do not use FIPS-validated cryptographic modules. However, SAS has tested with OpenSSL as the certificate generator on nodes where FIPS is enabled.

   In addition, certain types of storage might not work properly in a FIPS-enabled environment. Consult the documentation from the third-party vendor and implement workarounds where required.

   You can change the FIPS configuration of OpenSearch only with the initial deployment.

* **Disable FIPS mode for OpenSearch**: Customers who are currently running on FIPS-enabled nodes and do not wish to redeploy can use the `opendistro-disable-fips-transformer.yaml` transformer as a temporary workaround to disable OpenSearch FIPS mode. This transformer disables FIPS functionality for OpenSearch and therefore is not FIPS compliant. Do not use this transformer together with the `configure-opensearch-fips-transformer.yaml` transformer.

5. For additional customization options, refer to the following README files:

* Update the storage class used by OpenSearch: `$deploy/sas-bases/examples/configure-elasticsearch/internal/storage/README.md` (for Markdown format) or `$deploy/sas-bases/docs/configure_a_default_storageclass_for_opensearch.htm` (for HTML format).
* Configure a custom topology for OpenSearch: `$deploy/sas-bases/examples/configure-elasticsearch/internal/topology/README.md` (for Markdown format) or `$deploy/sas-bases/docs/configure_a_default_topology_for_opensearch.htm` (for HTML format).
* Configure a custom run user for OpenSearch: `$deploy/sas-bases/examples/configure-elasticsearch/internal/run-user/README.md` (for Markdown format) or `$deploy/sas-bases/docs/configure_a_run_user_for_opensearch.htm` (for HTML format).
* Additional configuration steps for Red Hat OpenShift: `$deploy/sas-bases/examples/configure-elasticsearch/internal/openshift/README.md` (for Markdown format) or `$deploy/sas-bases/docs/opensearch_on_red_hat_openshift.htm` (for HTML format).
* Additional configuration for OpenSearch Security Audit Logs: `$deploy/sas-bases/examples/configure-elasticsearch/internal/security-audit-logs/README.md` (for Markdown format) or `$deploy/sas-bases/docs/opensearch_security_audit_logs.htm` (for HTML format).
* Configure a temporary directory for JNA in OpenSearch: `$deploy/sas-bases/examples/configure-elasticsearch/internal/jna/README.md` (for Markdown format) or `$deploy/sas-bases/docs/configure_a_temporary_directory_for_jna_in_opensearch.htm` (for HTML format).

6. After you revise the base kustomization.yaml file, continue your SAS Viya platform
   deployment as documented in
   [SAS Viya Platform: Deployment Guide](http://documentation.sas.com/?softwareId=mysas&softwareVersion=prod&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm&locale=en).

## Supported Topologies

A single cluster is supported with the following topologies:

* One Node Set with both master and data roles.
* Two Node Sets: one with dedicated master role, and other with dedicated data role.
 
## Operator Constraints

The operator does not support the following actions:

* Dynamically changing a running cluster's properties, PersistentVolumeClaims or topology.
* Deleting PersistentVolumeClaims when a cluster is deleted.