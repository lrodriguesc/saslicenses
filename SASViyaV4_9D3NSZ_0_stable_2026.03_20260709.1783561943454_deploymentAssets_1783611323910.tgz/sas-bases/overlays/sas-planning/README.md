---
category: SAS Common Planning Service
tocprty: 3
---

# Configuring Customizations for sas-planning

## Overview

The sas-planning service uses the Common Data Store PostgreSQL as well as the one provided by platform.

This README describes the customizations needed for a PersistentVolumeClaim (PVC).
It also contains the steps required to configure an ingress-nginx timeout.


## Configure an Internal PostgreSQL Instance for sas-planning

### Instructions

#### Pre-upgrade steps

If updating from any release prior to 2023.09, please refer to [this documentation](https://documentation.sas.com/doc/en/intplancdc/v_001/mpag/n1qes6fbqcjrojn17gd61igx3z6l.htm#n00sew6hv7w4n4n1vuiojcw5d58h) for additional steps to follow.

#### Install CDS PostgreSQL

For more information on using an internal instance of PostgreSQL, you should
refer to the README file located at
`$deploy/sas-bases/examples/postgres/README.md`.

#### Customize Planning Overlays

Add the following overlay to the resources block of the base kustomization.yaml 
file (`$deploy/kustomization.yaml`):

```yaml
resources:
...
- sas-bases/overlays/sas-planning
...
```

Add the following overlays to the transformers block of the base kustomization.yaml 
file: 

```yaml
transformers:
...
- sas-bases/overlays/sas-planning/sas-planning-transformer.yaml
...
```

## Configure a PersistentVolume

A PersistentVolumeClaim (PVC) states the storage requirements from cloud
providers. The storage provided by cloud is mapped to the predefined paths across
services that collaborate to handle files. 

In the base kustomization.yaml file, immediately after the transformers block, add a patches block with the following content.

```yaml
...
patches:
- path: site-config/storageclass.yaml
  target:
    kind: PersistentVolumeClaim
    annotationSelector: sas.com/component-name in (sas-planning)
```

## Build

After you revise the base kustomization.yaml file, continue your SAS Viya platform
deployment as documented in
[SAS Viya Platform Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm&locale=en).