---
category: SAS Workload Orchestrator Service
tocprty: 2
---

# SAS Workload Orchestrator Server Service Overlays

## Overview

This directory contains overlays for configuring the SAS Workload Orchestrator Server Service. The SAS Workload Orchestrator Server Service is part of the SAS Workload Orchestrator Service providing an advanced scheduler that integrates with SAS Launcher to provide optimal resource allocation and workload management.

The available overlays include:

- **cluster-role**: Provides cluster-level privileges for optimal node and pod information access.
- **configure**: Configuration transformer used with the example configuration.env file to provide simple configuration changes.
Instructions for configuration are included in the README located at 
`$deploy/sas-bases/examples/sas-workload-orchestrator-server/configure/README.md` (for Markdown format) and at 
`$deploy/sas-bases/docs/configuration_settings_for_sas_workload_orchestrator_servers.htm` (for HTML format). 
- **enable-disable**: Tools to enable or disable the SAS Workload Orchestrator Server Service.

**IMPORTANT:** If you apply any overlay to the server/daemonset, you must apply the analogous overlay to the manager/statefulset. 

## Enabling Cluster Privileges to the SAS Workload Orchestrator Server Service (cluster-role)

### Overview

For the SAS Workload Orchestrator Service to perform optimally, it must be able to get information about nodes and pods in the cluster from the Kubernetes API server. In order to do that, SAS Workload Orchestrator service needs privileges at the cluster level, which are provided by a ClusterRole and ClusterRoleBinding being applied to the SAS Workload Orchestrator service account. SAS strongly recommends adding this overlay to allow the SAS Workload Orchestrator service account to retrieve the following node and pod information so that your deployment will run optimally.

* Node presence. This tells us whether the node is known by the Kubernetes server. If the node information cannot be accessed, SAS Workload Orchestrator assumes the node is viable from a status point of view even though kubelet might be dead.

* Node allocatable cores and memory. These are used to determine how much memory and how many cores are available to use for scheduling. If the node information cannot be accessed, SAS Workload Orchestrator only knows what the hardware contains, not what is available to Kubernetes to use for pods. Only kubelet knows those amounts.

* Node labels (referred to by SAS Workload Orchestrator as 'host properties'). If the node information cannot be accessed:
  * SAS Workload Orchestrator does not have host properties to use with host types.
    * SAS Workload Orchestrator uses host properties to assign a node to a host type. When host properties are not available, the host type must be selected another way, such as matching host name using regex values.
    * SAS Workload Orchestrator uses the host properties as node labels to set the nodeAffinity for pods that it scales. This setting is required to generate a scaling pod for a specific node pool. If there are no host properties, the scaling pod will only have the label 'workload.sas.com/class=compute' which could match more than one node pool.
  * SAS Workload Orchestrator cannot check to see whether the node has the 'workload.sas.com/class' label set to 'compute' so that it can schedule pods to the node. Instead, SAS Workload Orchestrator assumes it can schedule pods to any node where the SAS Workload Orchestrator DaemonSet pod is running.
* Node 'unschedulable' value. This is used to determine whether a node has been cordoned off so that no pods can be scheduled on it. If the node information cannot be accessed, SAS Workload Orchestrator still schedules pods to a cordoned-off node.
  **Note:** The ability for SAS Workload Manager to recognize that a node has been cordoned is new in release 2024.01.

* Resources used by pods from other namespaces running on the node. This is used to reduce the cores and memory available for scheduling. If the pod information about pods from other namespaces cannot be accessed, the amount of cores and memory available for scheduling is incorrect. This causes OutOfmemory and OutOfcpu launch errors.

**IMPORTANT:** SAS strongly recommends that deployments of SAS Workload Orchestrator
also have the ClusterRoleBinding. If you choose not to allow the ClusterRoleBinding, 
you must perform the following tasks:

* Prevent pods from other namespaces from running on the compute nodes that are used by the current namespace. This can be done by making both of these changes:
  * Have a node pool that has a special label for each namespace.
  * Change the pod templates for a deployment to require that special node label in the nodeAffinity.

* Group hosts by host name using a regular expression instead of host properties. The cloud vendor might generate node host names based in part on the node pool name.

* Close hosts in SAS Workload Orchestrator instead of using Kubernetes cordoning action.

* Limit the number of pods, jobs, or both that can be started on a node so that the total-pod-resource requirements fit within the nodes' available memory and cores.

* Prepare for kubelet to stop responding when it has a problem.

Without the ability to get node labels as host properties, SAS Workload Orchestrator cannot allocate a new node from the correct node pool when a pod triggers a scale-up. As stated above, SAS Workload Orchestrator uses the host properties (that is, node labels) of the host type to be scaled to create the scaling pod's nodeAffinity information. Without the host properties, the only label in the nodeAffinity section will be 'workload.sas.com/class=compute'. If you have only one deployment in a cluster and only one scalable node pool for the deployment, this is not a problem. If you have multiple deployments and each deployment has a scalable host type or multiple scalable host types, this is a problem because the node information cannot be accessed.

### Instructions for Enabling/Disabling the ClusterRole

**Note:** As of the 2025.12 cadence, the cluster role files located in
`/$deploy/sas-bases/overlays/sas-workload-orchestrator` 
has been split into manager (statefulset) files located in
`/$deploy/sas-bases/overlays/sas-workload-orchestrator/cluster-role` 
and server (daemonset) files located in
`/$deploy/sas-bases/overlays/sas-workload-orchestrator-server/cluster-role`.

This document will only detail instructions for the server/daemonset pods.
For details about the manager/statefulset ClusterRole, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).

#### Updating kustomization.yaml

##### Enable the ClusterRole

The ClusterRole and ClusterRoleBinding are enabled by adding the cluster role resources to the resources block of the base kustomization.yaml file
(`$deploy/kustomization.yaml`). Here is an example:

```yaml
resources:
...
- sas-bases/overlays/sas-workload-orchestrator-server/cluster-role
```

##### Disable the ClusterRole

To disable the ClusterRole and ClusterRoleBinding:

1. Remove the reference to `sas-bases/overlays/sas-workload-orchestrator-server/cluster-role` from the resources block of the
base kustomization.yaml file (`$deploy/kustomization.yaml`). This also ensures that the
ClusterRole option will not be applied in future Kustomize builds.

2. Perform the following command to remove the ClusterRoleBinding from the namespace:

   ```bash
   kubectl delete clusterrolebinding sas-workload-orchestrator-server-<your namespace>
   ```

3. Perform the following command to remove the ClusterRole from the cluster.

   ```bash
   kubectl delete clusterrole sas-workload-orchestrator-server
   ```

#### Build

After you configure Kustomize, continue your SAS Viya platform deployment as documented.

## Enabling and Disabling the SAS Workload Orchestrator Server Service (enable-disable)

### Overview

The SAS Workload Orchestrator Server Service consists of a set of server
pods controlled by the sas-workload-orchestrator statefulset and
a set of server pods controlled by the sas-workload-orchestrator-server
daemonset.

This section describes how to automatically disable (or enable)
the SAS Workload Orchestrator Server Service by disabling (or enabling) the
sas-workload-orchestrator-server daemonset.

**Note:** This document will only detail instructions for the server/daemonset pods.
For details about disabling the manager/statefulset pods, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).

### Instructions

#### Automatically Disable the SAS Workload Orchestrator Server Service

Because the SAS Workload Orchestrator Server Service is enabled by default,
there is no action needed to automatically enable the daemonset pods.

You can automatically disable the SAS Workload Orchestrator Server pods
by adding a patch transformer to the main kustomization.yaml
file so that no daemonset pods are created.

**Note:** Automatically disabling SAS Workload Orchestrator Server Service 
causes it to remain disabled even if an update is made to the deployment. 

##### Updating kustomization.yaml

To automatically disable the service, add a reference to the disable patch
transformer file into the transformers block of the base kustomization.yaml
file (`$deploy/kustomization.yaml`).

Here is an example:

```yaml
transformers:
...
- sas-bases/overlays/sas-workload-orchestrator-server/enable-disable/sas-workload-orchestrator-server-disable-patch-transformer.yaml
```
##### Build

After you configure Kustomize, continue your SAS Viya platform deployment as documented.

#### Manually Disable or Enable the SAS Workload Orchestrator Server Service

Manually enable or disable the SAS Workload Orchestrator Server Service
daemonset pods by using the 'kubectl patch' command along with supplied 
patch files. There are two files, one for enabling the daemonset, and 
one for disabling the daemonset.

Since manually disabling or enabling of the SAS Workload Orchestrator Server Service
is done from a machine that is running kubectl with access to the cluster,
the files from `$deploy/sas-bases/overlays/sas-workload-orchestrator-server/enable-disable`
must be accessible on that machine either by mounting the overlays directory to the
machine or copying the files to the machine running the kubectl command.

**Note:** Manually disabling the SAS Workload Orchestrator Server Service is 
temporary. If an update is applied to the deployment, SAS Workload Orchestrator 
Service will be enabled again. 

##### Disabling

Terminate the daemonset pods:

```bash
kubectl -n <namespace> patch daemonset sas-workload-orchestrator-server --patch-file /<path>/<to>/sas-workload-orchestrator-server-disable-patch.yaml
```

##### Enabling

Enable the daemonset pods:

```bash
kubectl -n <namespace> patch daemonset sas-workload-orchestrator-server --patch-file /<path>/<to>/sas-workload-orchestrator-server-enable-patch.yaml
```