---
category: SAS Workload Orchestrator Service
tocprty: 4
---

# SAS Workload Orchestrator Server Service Examples

## Overview

This directory contains various example files for configuring the SAS Workload Orchestrator Server Service. The SAS Workload Orchestrator Server Service is part of the 
SAS Workload Orchestrator Service, which is an advanced scheduler that integrates with SAS Launcher to provide optimal resource allocation and workload management.

## Configuration Settings for SAS Workload Orchestrator Service

### Overview

The SAS Workload Orchestrator Service manages the workload which is started on demand by the launcher service.
The SAS Workload Orchestrator Service has manager pods in a StatefulSet and works with the 
SAS Workload Orchestrator Server Service pods in a DaemonSet.

This README file describes the changes that can be made to the SAS Workload
Orchestrator Server Service (daemonset) settings for pod resource requirements, for
user-defined resource scripts, and for specifying a different Prometheus 
Pushgateway URL than the default.

**IMPORTANT:** SAS strongly recommends that deployments of SAS Workload Orchestrator
also have the ClusterRoleBinding. 
For details about the statefulset ClusterRole, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).
For details about the daemonset ClusterRole, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator-server/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).

#### Pod Resource Requests and Limits

Kubernetes pods have resource requests and limits for CPU and memory.

Server pods interact with Kubernetes to manage the resources and jobs running
on a particular node. Their memory and core requirements depend on how jobs are
allowed to concurrently run on a node and how many pods not started by the
SAS Workload Orchestrator Server Service are also running on a node.
For server pods, the current default resource request and limit for CPU and
memory is 0.1 core and 250MB of memory.

#### Pod User-Defined Script Volume

SAS Workload Orchestrator allows user-defined resources to be used
for scheduling. User-defined resources can be a specified value or can
be a value returned by executing a script.

Server pods handle the running of user-defined resource scripts for
resources that reflect values about an individual node that a pod would run on.
An example of a host resource could be number of GPUs on a host (for the
case of a static resource) or the amount of disk space left on a mount (for
the case of a dynamic resource).

In order to set these values, SAS Workload Orchestrator looks for a script
in a volume mount named "/scripts". To place a script in that directory,
the script must be placed in a volume and that volume specified in the
DaemonSet definition as a volume with the name 'scripts'.

#### Custom Prometheus Pushgateway

The Prometheus Pushgateway used by SAS Workload Orchestrator
can be specified by an environment variable allowing customers to change where
SAS Workload Orchestrator sends its metric information. A patch transformer is provided
to allow a custom URL to be set in the SAS Workload Orchestrator Daemonset configuration.
If the environment variable is not specified, the metrics are sent to
`http://prometheus-pushgateway:9091`.

### Installation 

As of the 2025.12 cadence, most configuration values are now stored in a single `configuration.env` file
located in the `/$deploy/sas-bases/examples/sas-workload-orchestrator-server/configure` directory.
Configuration of the host user-defined resource script volume is handled separately since its
configuration cannot be represented by simple string values.

#### Make a Copy of configuration.env

If you want to make any changes to the configuration settings found in `configuration.env`,
you should do the following:

1. Copy the `/$deploy/sas-bases/examples/sas-workload-orchestrator-server/configure/configuration.env`
file to your site-config directory as 
`/$deploy/site-config/sas-workload-orchestrator-server/configure/configuration.env`.
2. Uncomment and modify the lines for the settings you want to configure.
3. Add a `merge` behavior to the base kustomization.yaml file (`/$deploy/kustomization.yaml`) to merge in the settings
from `/$deploy/site-config/sas-workload-orchestrator-server/configure/configuration.env`. Here is an example:

   ```yaml
   configMapGenerator:
   ...
   - behavior: merge
     envs:
     - /site-config/sas-workload-orchestrator-server/configure/configuration.env
     name: sas-workload-orchestrator-server-user-configuration
   ```

4. Add the `/$deploy/sas-bases/overlays/sas-workload-orchestrator-server/configure/transformers.yaml` to the transformers
block of the base kustomization.yaml file (`/$deploy/kustomization.yaml`) to apply the updated settings
in the sas-workload-orchestrator-server-user-configuration ConfigMap to the proper Kubernetes objects. Here is an example:

   ```yaml
   transformers:
   ...
   - sas-bases/overlays/sas-workload-orchestrator-server/configure/transformers.yaml
   ```

#### SAS Workload Orchestrator Server Pods Requests and Limits

The values for memory and CPU resources for the SAS Workload Orchestrator Service pods
are in the `configuration.env` file by default as

```bash
#--------------------------------------------------------------------
# Daemonset (server) pod resource configuration
# daemonset-requests-mem={{ DAEMONSET-MEM-REQUIRED }}
# daemonset-limits-mem={{ DAEMONSET-MEM-LIMIT }}
# daemonset-requests-cpu={{ DAEMONSET-CPU-REQUIRED }}
# daemonset-limits-cpu={{ DAEMONSET-CPU-LIMIT }}
```

To update one or more of the defaults: 

1. Uncomment the line for the value you want to set.
2. Replace the `{{ *-MEM-REQUIRED }}`, `{{ *-MEM-LIMIT }}`, `{{ *-CPU-REQUIRED }}`, or `{{ *-CPU-LIMIT }}` variable
with the value you want to use. 
   * `{{ *-MEM-REQUIRED }}` and `{{ *-CPU-REQUIRED }}` are the minimum amount required to run.
   * `{{ *-MEM-LIMIT }}` and `{{ *-CPU-LIMIT }}` are the maximum allowed values. If the pod goes over `{{ *-MEM-LIMIT }}`, the pod will be terminated.

Here is an example that sets

* Daemonset (server pods) memory to a starting value of 500Mi to a max of 2000Mi.
* Daemonset (server pods) cpu to a starting value of 0.15 cores to a max of 1.5 cores.

   ```bash
   #--------------------------------------------------------------------
   # Daemonset (server) pod resource configuration
   daemonset-requests-mem=500Mi
   daemonset-limits-mem=2000Mi
   daemonset-requests-cpu=150m
   daemonset-limits-cpu=1500m
   ```

**Notes:** 

* Only the values you want modified need to be changed.
* For details on the resource value syntax used in the code, see
[Resource units in Kubernetes](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/#resource-units-in-kubernetes).

#### Changing Prometheus Pushgateway URL

The value for the Prometheus Pushgateway URL that SAS Workload Orchestrator should use
is in the `configuration.env` file by default as

```bash
# prometheus-push-gateway-url={{ PROMETHEUS-PUSHGATEWAY-URL }}
```

To update the URL, uncomment the line and replace the `{{ PROMETHEUS_PUSHGATEWAY_URL }}` variable with the URL where SAS Workload Orchestrator should push its metrics. 

Here is an example that sets the URL to `https://my-prometheus-pushgateway.mycompany.com`

```bash
prometheus-push-gateway-url=https://my-prometheus-pushgateway.mycompany.com
```

## User-Defined Scripts Volume for Server Pods

When a user-defined resource uses a script to return a resource value, 
the filesystem that contains that script needs to be made available to the pod in a location 
specified in the configuration. Mounting a filesystem into the pod requires that a volume 
and volumeMount be added to the pod definition. By default, SAS Workload Orchestrator configuration
expects user-defined resource scripts to be the `/scripts` directory and backed by a volume
name `scripts`. An example of patch transformer that mounts an NFS volume as the `scripts` volume
is in the example file `sas-workload-orchestrator-server-host-user-defined-resources-script-storage.yaml`.

1. Copy the `/$deploy/sas-bases/examples/sas-workload-orchestrator-server/configure/sas-workload-orchestrator-server-host-user-defined-resources-script-storage.yaml`
file to your site-config directory as 
`/$deploy/site-config/sas-workload-orchestrator-server/configure/sas-workload-orchestrator-server-host-user-defined-resources-script-storage.yaml`.
2. Replace the `{{ NFS-SERVER-ADDR }}` variable with the fully-qualified domain name of the server and 
replace the `{{ NFS-SERVER-PATH }}` variable with the path to the volume on the server. Here is an example:

   ```yaml
     - op: replace
       path: /spec/template/spec/volumes/0
       value:
         name: scripts
         nfs:
           path: /path/to/my/scripts
           server: my.nfs.server.mydomain.com
   ```

Alternately, you could use any other type of volume Kubernetes supports.

The following example updates the volume to use a PersistentVolumeClaim
instead of an NFS mount. This assumes the PVC has already been defined and created.

```yaml
  - op: replace
    path: /spec/template/spec/volumes/0
    value:
      name: scripts
      persistentVolumeClaim:
        claimName: my-pvc-name
        readOnly: true
```

**Note:** For details on the value syntax used specifying volumes, see
[Kubernetes Volumes](https://kubernetes.io/docs/concepts/storage/volumes/).

After you have edited the file, add a reference to it to the transformers
block of the base kustomization.yaml file (`$deploy/kustomization.yaml`). Here is an example:

```yaml
transformers:
...
- site-config/sas-workload-orchestrator-server/configure/sas-workload-orchestrator-server-host-user-defined-resources-script-storage.yaml
```