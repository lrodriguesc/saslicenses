---
category: auditing
tocprty: 7
---

# Disabling Log Correlation

## Overview

The default log correlation feature ensures that log messages associated with a request include the
`trace_id` and `span_id` baggage associated with an OpenTelemetry trace as log message properties,
as well as ensuring that the `traceId` field of audit entries is populated with the correct trace
identifier. Disabling log correlation via the disable-log-correlation overlay will disable all the
previously mentioned features, which may improve CPU usage at the cost of ease of debugging and
system observability.

Disabling log correlation should only be done when the following statements are true:

1. Tracing information from logs and entries in the Audit service are not needed for legal compliance.
2. You do not currently need assistance from technical support. In the event that you do need
   assistance, technical support may request that you re-enable log correlation.
3. Pods within an existing deployment are hitting CPU usage limits, and were not prior to 2025.10.

## Installation

To apply the overlay, add the `sas-bases/overlays/performance/disable-log-correlation.yaml` to
the transformers block in your base kustomization.yaml file. Here is an example:

```yaml
...
transformers:
...
- sas-bases/overlays/performance/disable-log-correlation.yaml
```
