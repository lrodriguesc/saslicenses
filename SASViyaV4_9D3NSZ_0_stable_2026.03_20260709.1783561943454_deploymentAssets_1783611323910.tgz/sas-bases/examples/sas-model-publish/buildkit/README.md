---
category: Model Publish service
tocprty: 3
---

# Configure BuildKit for SAS Model Publish Service

## Overview

BuildKit is a tool that is used to build container images from a Dockerfile
without depending on a Docker daemon. BuildKit can build a container image in
Kubernetes, and then push the built image to the container registry for a
specific destination.

The Model Publish service uses the dedicated sas-model-publish-buildkit
PersistentVolumeClaim (PVC) to store temporary assets required during the
deployment process.

An Update request is sent from the Model Publish service to the Decisions
Runtime Builder service, which starts a kubernetes job that builds a new image.
The service checks the job status every 30 seconds. If a job is not complete
after 30 minutes, it times out.

The Model Publish service deletes the job and the temporary directories after
the job has completed successfully, completed with errors, or has timed out.

## Installation

1. Copy the files in the `$deploy/sas-bases/examples/sas-model-publish/buildkit`
   directory to the `$deploy/site-config/sas-model-publish/buildkit` directory.
   Create the destination directory, if it does not already exist.

   **Note:** [Verify that the overlay](#verify-the-buildkit-overlay) has been
   applied. If the BuildKit daemon deployment already exists, you do not need to
   take any further action, unless you want to change the overlay parameters for
   the mounted directory.

2. Modify the parameters in `configuration.env`. By default, the resource
   requests are set to 1 CPU core and 1Gi memory, the memory limit is set to
   1Gi, and the maximum number of replicas for the Buidlkit daemon pod is set
   to 1.

   - Replace {{ BUILDKIT-STORAGE-SIZE }} with the amount of storage required.
   - Replace {{ BUILDKIT-STORAGE-CLASS }} with the appropriate storage class.
   - Replace the default values for buildkitCpuRequest and buildkitMemoryRequest
     with the amount of CPU and memory requests.
   - Replace the default value for buildkitMemoryLimit with the amount of memory
     limit.
   - Replace the default value for buildkitMaxReplicas with the desired max
     replica count for the BuildKit daemon.

   Here is an example:

   ```env
   buildkitStorageSize=1Gi
   buildkitStorageClass=nfs-client
   buildkitCpuRequest=0.5
   buildkitMemoryRequest=1Gi
   buildkitMemoryLimit=2Gi
   buildkitMaxReplicas=3
   ```

   **Important:** The PVC requires `ReadWriteMany` access mode. Certain storage
   classes, such as Azure managed disks (`managed-csi-premium`), support only
   `ReadWriteOnce` access and will fail. Use a storage class that supports
   `ReadWriteMany` access, such as Azure Files or NFS.

   For more information about PersistentVolume Claims (PVCs), see
   [Persistent Volume Claims on Kubernetes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#persistentvolumeclaims).

   **Note:** If the base kustomization.yaml file includes
   `sas-bases/overlays/scaling/ha/enable-ha-transformer.yaml`, High Availability
   (HA) is enabled. The HA transformer will override the `buildkitMaxReplicas`
   value set in `configuration.env`. To ensure that the `buildkitMaxReplicas`
   value takes priority, list `buildkit-transformer.yaml` after the
   `enable-ha-transformer.yaml` entry in the `transformers` block. Here is an
   example:

   ```yaml
   transformers:
     - sas-bases/overlays/scaling/ha/enable-ha-transformer.yaml
     - sas-bases/overlays/sas-model-publish/buildkit/buildkit-transformer.yaml
   ```

3. (OpenShift deployments only) The fsGroup field assigns a supplemental GID
   used by all containers in the pod. On OpenShift, you must set (or allow the
   SCC to set) an appropriate fsGroup; it is optional in other environments. To
   change the fsGroup value, see:
   `$deploy/sas-bases/examples/security/container-security/README.md`

   **Note:** For OpenShift, you can obtain the allocated GID and value by using
   this command:

   ```bash
   kubectl describe namespace <name-of-namespace>
   ```

   Use the minimum value of the `openshift.io/sa.scc.supplemental-groups`
   annotation. For example, if the output is as follows, you would use
   `1000700000`.

   ```yaml
   Name:         sas-1
   Labels:       <none>
   Annotations:  ...
                 openshift.io/sa.scc.supplemental-groups: 1000700000/10000
                 ...
   ```

4. Make the following changes to the base kustomization.yaml file in the $deploy
   directory.

   - Add site-config/sas-model-publish/buildkit to the resources block.
   - Add sas-bases/overlays/sas-model-publish/buildkit to the resources block.
   - Add sas-bases/overlays/sas-model-publish/buildkit/buildkit-transformer.yaml
     to the transformers block.

   Here is an example:

   ```yaml
   resources:
     - site-config/sas-model-publish/buildkit
     - sas-bases/overlays/sas-model-publish/buildkit

   transformers:
     - sas-bases/overlays/sas-model-publish/buildkit/buildkit-transformer.yaml
   ```

5. Complete the deployment steps to apply the new settings. See
   [Deploy the Software](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=p127f6y30iimr6n17x2xe9vlt54q.htm)
   in _SAS Viya Platform: Deployment Guide_.

   **Note:** This overlay can be applied during the initial deployment of the
   SAS Viya platform or after the deployment of the SAS Viya platform.

   - If you are applying the overlay during the initial deployment of the SAS
     Viya platform, complete all the tasks in the README files that you want to
     use, then run `kustomize build` to create and apply the manifests.
   - If the overlay is applied after the initial deployment of the SAS Viya
     platform, run `kustomize build` to create and apply the manifests.

6. (OpenShift deployments only) Apply a security context constraint (SCC):

   If you have not already, apply and bind the SCC to the appropriate service
   accounts that will use it. For more details, see
   [Apply and Bind the Security Context Constraints](https://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=p1h8it1wdu2iaxn1bkd8anfcuxny.htm#p0ovs3p7bgep9in12qsrtwk3rn01).

## Remove Resource Limits from BuildKit

When the volume of publish requests varies significantly, it can be challenging
to set appropriate resource limits for BuildKit. To remove these limits, revise
the base kustomization.yaml file in the $deploy directory by adding
`sas-bases/overlays/sas-model-publish/buildkit/buildkit-remove-limits.yaml` to
the transformers block after the `buildkit-transformer.yaml` entry. Here is an
example:

```yaml
transformers:
  - sas-bases/overlays/sas-model-publish/buildkit/buildkit-transformer.yaml
  - sas-bases/overlays/sas-model-publish/buildkit/buildkit-remove-limits.yaml
```

## Using BuildKit on Clusters with an Incorrect User Namespace Configuration

The sas-buildkitd deployment typically starts without any issues. However, for
some cluster deployments, you might receive the following error:

```yaml
/proc/sys/user/max_user_namespaces needs to be set to nonzero
```

If this occurs, use the buildkit-userns-transformer to configure user namespace
support. This is done with an init container that is running in privileged mode
during start-up.

1. Add
   'sas-bases/overlays/sas-model-publish/buildkit/buildkit-userns-transformer.yaml'
   to the transformers block after the 'buildkit-transformer.yaml' entry. Here
   is an example:

   ```yaml
   transformers:
     - sas-bases/overlays/sas-model-publish/buildkit/buildkit-transformer.yaml
     - sas-bases/overlays/sas-model-publish/buildkit/buildkit-userns-transformer.yaml
   ```

2. Complete the deployment steps to apply the new settings. See
   [Deploy the Software](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=p127f6y30iimr6n17x2xe9vlt54q.htm)
   in _SAS Viya Platform: Deployment Guide_.

## Using BuildKit with Registries That Use Self-Signed Certificates

BuildKit deployments pull base layers from source registries and publish
container images to target registries. If the source registry that contains SAS
Viya platform deployment images, or the destination registry, uses self-signed
certificates, the certificates should be added to the BuildKit deployment via
the certificate framework.

To incorporate additional CA certificates, follow the instructions in the
"Incorporating Additional CA Certificates" section of the README file located at
`$deploy/sas-bases/examples/security/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/configure_network_security_and_encryption_using_sas_security_certificate_framework.htm`
(for HTML format).

## Verify the BuildKit Overlay

Run the following command to verify whether the BuildKit overlay has been
applied. It should show at least one pod starting with the prefix 'buildkitd'.

```sh
kubectl -n <name-of-namespace> get pods  |  grep buildkitd
```

## Additional Resources

- [SAS Viya platform: Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm)
- [Persistent Volume Claims on Kubernetes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#persistentvolumeclaims)
- [Configuring Publishing Destinations](http://documentation.sas.com/?cdcId=mdlmgrcdc&cdcVersion=default&docsetId=mdlmgrag&docsetTarget=n0x0rvwqs9lvpun16sfdqoff4tsk.htm)
  in the _SAS Model Manager: Administrator's Guide_
- [Set environment variable in a Kubernetes deployment](https://www.mankier.com/1/kubectl-set-env)
