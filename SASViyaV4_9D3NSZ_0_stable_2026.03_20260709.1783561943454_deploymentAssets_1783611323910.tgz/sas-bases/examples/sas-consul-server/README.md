---
category: consul
tocprty: 3
---

# Configure Storage Class for SAS Configuration Server

## Overview

> **Note:** This configuration is intended for new deployments only. Do not apply 
> this storage class configuration to an existing deployment as it will result in 
> data loss.

> **Warning:** After you deploy SAS Configuration Server with a storage class specified, 
> do not change the storage class. Changing the storage class after deployment 
> results in data loss and service disruption.

SAS Configuration Server uses persistent volumes to store data. By default, SAS Configuration Server uses a persistent volume claim with no storage class specified. This README describes how to configure the storage class for the persistent volume claims used by SAS Configuration Server to match your environment's requirements.

## Instructions

1. Copy the `sas-consul-server.env` file from `$deploy/sas-bases/examples/sas-consul-server`
   to the site-config directory, `$deploy/site-config/sas-consul-server/`.

   ```bash
   mkdir -p $deploy/site-config/sas-consul-server
   cp $deploy/sas-bases/examples/sas-consul-server/sas-consul-server.env \
      $deploy/site-config/sas-consul-server/sas-consul-server.env
   ```

2. Edit the `$deploy/site-config/sas-consul-server/sas-consul-server.env` file to 
   specify the desired storage class name. Uncomment the `consulServerStorageClassName` line 
   and set the desired storage class (for example, `consulServerStorageClassName=new-rwo-block-storage`).

3. Add a reference to the file in the configMapGenerator block of the base 
   kustomization.yaml file (`$deploy/kustomization.yaml`).

   ```yaml
   configMapGenerator:
   ...
   - behavior: merge
     envs:
     - site-config/sas-consul-server/sas-consul-server.env
     name: sas-consul-server
   ```

4. Add a reference to the resources in the resources block of the base 
   kustomization.yaml file.

   ```yaml
   resources:
   ...
   - sas-bases/overlays/sas-consul-server/resources
   ```

5. Add a reference to the transformer in the transformers block of the base 
   kustomization.yaml file.

   ```yaml
   transformers:
   ...
   - sas-bases/overlays/sas-consul-server/storage-class-transformer.yaml
   ```

## Additional Resources

For more information about using example files, see the [SAS Viya Platform Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm).
