---
category: contour
tocprty: 2
---

# Configuring General Contour HTTPProxy Options

## Overview

You can use the examples found within `$deploy/sas-bases/examples/httpproxy-configuration/` to set general configuration values for Contour HTTPProxy resources.

## Configurable Values

* The INGRESS_CLASS_NAME value specifies the name of the IngressClass which SAS Viya platform HTTPProxy resources should use for this deployment. By default, SAS Viya platform HTTPProxy resources will use the `contour` IngressClass. For more information about IngressClass resources, see [Ingress class](https://kubernetes.io/docs/concepts/services-networking/ingress/#ingress-class) and [Using IngressClasses](https://kubernetes.github.io/ingress-nginx/user-guide/multiple-ingress/#using-ingressclasses).

  The transformer file to override the ingressClassName field in HTTPProxy resources is found at `sas-bases/overlays/httpproxy-configuration/update-ingress-classname.yaml`.

* The IDLE_CONNECTION_TIMEOUT value specifies the amount of time that connections between Contour and SAS Viya platform applications remain idle before being closed by the proxy server. The default for this value comes from Envoy and is set at one hour. SAS has observed that this can result in open sockets increasing in number during high traffic. Set this value to a shorter duration if your environment is encountering issues due to a high number of open sockets. Values must be [valid Go duration strings](https://pkg.go.dev/time#ParseDuration).

  The transformer file to override the idleConnection field in HTTPProxy resources is found at `sas-bases/overlays/httpproxy-configuration/update-idle-timeout.yaml`.

* The SESSION_COOKIE_SAME_SITE value specifies the value of the sameSite attribute in the Contour session affinity cookie. This cookie ensures clients are routed to a consistent SAS Viya platform Pod. By default, Contour does not set this attribute, instead deferring to web browser defaults. Setting this value also ensures the `Secure` cookie property is set. Values must be one of `Strict`, `Lax`, or `None`.

  The transformer file to override the sameSite field in HTTPProxy resources is found at `sas-bases/overlays/httpproxy-configuration/update-session-cookie-samesite.yaml`.

## Installation

Use these steps to apply the desired properties to your SAS Viya platform deployment.

1. Copy the `$deploy/sas-bases/examples/httpproxy-configuration/httpproxy-configuration-inputs.yaml` file to the location of your working directory, such as `site-config/httpproxy-configuration/`.

2. Define the properties in the httpproxy-configuration-inputs.yaml file which match the desired configuration. To define a property, uncomment it and update its token value as described in the comments in the file.

3. Add the relative path of httpproxy-configuration-inputs.yaml to the resources block of the base kustomization.yaml file (`$deploy/kustomization.yaml`). Here is an example:

   ```yaml
   ...
   resources:
   ...
   - site-config/httpproxy-configuration/httpproxy-configuration-inputs.yaml
   ...
   ```

4. Add the relative path of the corresponding transformer file or files to the transformers block of the base kustomization.yaml file. There should be one transformer file added per option defined within the httpproxy-configuration-inputs.yaml file. Here is an example:

   ```yaml
   ...
   transformers:
   ...
   - sas-bases/overlays/httpproxy-configuration/update-ingress-classname.yaml
   ...
   ```
