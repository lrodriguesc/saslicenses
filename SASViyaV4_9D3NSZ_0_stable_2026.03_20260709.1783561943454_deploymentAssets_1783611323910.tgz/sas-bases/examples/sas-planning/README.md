---
category: SAS Common Planning Service
tocprty: 1
---

# Configure Kubernetes PersistentVolumeClaim for SAS Common Planning Service

## Overview
SAS Common Planning Service, used by SAS Assortment Planning, SAS Demand Planning, and SAS Financial Planning, requires dedicated PersistentVolumeClaims (PVCs) for
storing data. During setup the sas-planning-retail PVCs are defined and then mounted in the startup process.
This directory contains an example transformer that illustrates how to change the StorageClass and size of the PVCs.

## Installation
1. Copy the `$deploy/sas-bases/examples/sas-planning/storage.yaml` file to the 
  `$deploy/site-config` directory.
2. Revise the copied file according to the comments in the file, replacing the 
   variables with the appropriate values.
3. Add a reference to the base kustomization.yaml file (`$deploy/kustomization.yaml`)
  for the revise file. Here is an example that assumes you put the copied file in 
  `$deploy/site-config/sas-planning/storage.yaml`:

  ```yaml
  transformers:
  ...
  - site-config/sas-planning/storage.yaml
  ```
4. Continue your SAS Viya platform deployment as documented in
  [SAS Viya Platform Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm&locale=en).


# Configure Kubernetes ingress-nginx time out for SAS Common Planning Service

## Overview
To avoid issues related to client timeouts, configure SAS Common Planning Service ingress-nginx timeout.

##Installation
1. Copy the `$deploy/sas-bases/examples/sas-planning/sas-planning-ingress-patch.yaml` file to the 
  `$deploy/site-config` directory.
2. Revise the copied file according to the comments in the file, replacing the 
   variables with the appropriate values.
3. Add a reference to the base kustomization.yaml file (`$deploy/kustomization.yaml`)
  for the revise file. Here is an example that assumes you put the copied file in 
  `$deploy/site-config/sas-planning/sas-planning-ingress-patch.yaml`:

  ```yaml
  transformers:
  ...
  - site-config/sas-planning/sas-planning-ingress-patch.yaml
  ```
4. Continue your SAS Viya platform deployment as documented in
  [SAS Viya Platform Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm&locale=en).