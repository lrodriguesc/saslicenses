---
category: SAS/CONNECT Spawner
tocprty: 2
---

# Granting Security Context Constraints on an OpenShift Cluster for SAS/CONNECT

Although SAS/CONNECT Spawner has deprecated the ability to locally launch server pods, there is still 
a requirement to have the security contexts constraints (SCCs) for the sas-connect-spawner pod granted on an OpenShift cluster.

The `$deploy/sas-bases/examples/sas-connect-spawner/openshift` directory contains a file to
grant SCCs for the sas-connect-spawner pod on an OpenShift cluster.
A Kubernetes cluster administrator should add these SCCs
to their OpenShift cluster prior to deploying the SAS Viya platform.

1. As a Kubernetes cluster administrator of the OpenShift cluster, use one of the following sets of commands to apply the SCCs.

   ```sh
   kubectl apply -f sas-connect-spawner-scc.yaml
   ```

   or

   ```sh
   oc create -f sas-connect-spawner-scc.yaml
   ```

2. Use the following command to link the SCCs to Kubernetes ServiceAccounts. Replace the entire variable {{ NAME-OF-NAMESPACE }}, including the braces, with the Kubernetes namespace used for the SAS Viya platform.

   ```sh
   oc -n {{ NAME-OF-NAMESPACE }} adm policy add-scc-to-user sas-connect-spawner -z sas-connect-spawner
   ```