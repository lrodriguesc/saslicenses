---
category: dataServer
tocprty: 45
---

# SAS Viya Platform with Oracle
 
Content in the `sas-bases/examples/oracle` directory is not for general consumption.

Early adopters have been provided the relevant resources.