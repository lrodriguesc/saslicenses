---
category: SAS Workload Orchestrator Service
tocprty: 3
---
# SAS Workload Orchestrator Service Examples

## Overview

This directory contains examples for configuring the SAS Workload Orchestrator Service. The SAS Workload Orchestrator Service is an advanced scheduler that integrates with SAS Launcher to provide optimal resource allocation and workload management.

## Configuration Settings for SAS Workload Orchestrator Service

### Overview

The SAS Workload Orchestrator Service manages the workload, which is started on demand by the launcher service.
The SAS Workload Orchestrator Service has manager pods in a StatefulSet and works with the 
SAS Workload Orchestrator Server Service pods in a DaemonSet.

This README file describes the changes that can be made to the SAS Workload
Orchestrator manager settings for pod resource requirements, for
global user-defined resource scripts, and for the initial configuration 
of the service. The setting for the server (daemonset) settings are in
the sas-workload-orchestrator-server's `examples` directory.

**IMPORTANT:** SAS strongly recommends that deployments of SAS Workload Orchestrator
also have the ClusterRoleBinding. 
For details about the statefulset ClusterRole, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).
For details about the daemonset ClusterRole, see the README located at
`$deploy/sas-bases/overlays/sas-workload-orchestrator-server/README.md` (for Markdown format) or at
`$deploy/sas-bases/docs/cluster_privileges_for_sas_workload_orchestrator_service.htm` (for HTML format).

#### Pod Resource Requests and Limits

Kubernetes pods have resource requests and limits for CPU and memory.

Manager pods handle all the REST API calls and manage all of the processing
of host, job, and queue information. The more jobs you process at the same time,
the more memory and cores you should assign to the StatefulSet pods.
For manager pods, the current default resource request and limit for CPU and
memory is 1 core and 4GB of memory.

#### Pod User-Defined Script Volume

SAS Workload Orchestrator allows user-defined resources to be used
for scheduling. User-defined resources can be a specified value or can
be a value returned by executing a script.

Manager pods handle the running of user-defined resource scripts for
resources that affect the scheduling on a global scale. An example of
a global resource would be the number of licenses across all pods started
by SAS Workload Orchestrator.

In order to set these values, SAS Workload Orchestrator looks for a script
in a volume mount named "/scripts". To place a script in that directory,
the script must be placed in a volume and that volume specified in the
StatefulSet or DaemonSet definition as a volume with the name 'scripts'.

#### SAS Workload Orchestrator Initial Configuration

The default SAS Workload Orchestrator configuration is
loaded from the sas-workload-orchestrator-initial-configuration ConfigMap.
If the initial configuration needs to be modified, the ConfigMap can be
modified by a patch transformer.

### Installation 

As of the 2025.12 cadence, most configuration values are now stored in a single `configuration.env` file
located in the `/$deploy/sas-bases/examples/sas-workload-orchestrator/configure` directory.
Configuration of the global user-defined resource script volume is handled separately since its
configuration cannot be handled by simple string values.

#### Make a Copy of configuration.env

If you want to make any changes to the configuration settings found in `configuration.env`,
you should do the following:

1. Copy the `/$deploy/sas-bases/examples/sas-workload-orchestrator/configure/configuration.env`
file to your site-config directory as 
`/$deploy/site-config/sas-workload-orchestrator/configure/configuration.env`.
2. Uncomment and modify the lines for the settings you want to configure.
3. Add a `merge` behavior to the base kustomization.yaml file (`/$deploy/kustomization.yaml`) to merge in the settings
from `/$deploy/site-config/sas-workload-orchestrator/configure/configuration.env`. Here is an example:

   ```yaml
   configMapGenerator:
   ...
   - behavior: merge
     envs:
     - /site-config/sas-workload-orchestrator/configure/configuration.env
     name: sas-workload-orchestrator-user-configuration
   ```

4. Add the `/$deploy/sas-bases/overlays/sas-workload-orchestrator/configure/transformers.yaml` to the transformers
block of the base kustomization.yaml file (`/$deploy/kustomization.yaml`) to apply the updated settings
in the sas-workload-orchestrator-user-configuration ConfigMap to the proper Kubernetes objects. Here is an example:

   ```yaml
   transformers:
   ...
   - sas-bases/overlays/sas-workload-orchestrator/configure/transformers.yaml
   ```

#### SAS Workload Orchestrator Pods Requests and Limits

The values for memory and CPU resources for the SAS Workload Orchestrator Service pods
are in the `configuration.env` file by default as

```bash
#--------------------------------------------------------------------
# Statefulset (manager) pod resource configuration
# statefulset-requests-mem={{ STATEFULSET-MEM-REQUIRED }}
# statefulset-limits-mem={{ STATEFULSET-MEM-LIMIT }}
# statefulset-requests-cpu={{ STATEFULSET-CPU-REQUIRED }}
# statefulset-limits-cpu={{ STATEFULSET-CPU-LIMIT }}

```

To update one or more of the defaults: 

1. Uncomment the line for the value you want to set.
2. Replace the `{{ *-MEM-REQUIRED }}`, `{{ *-MEM-LIMIT }}`, `{{ *-CPU-REQUIRED }}`, or `{{ *-CPU-LIMIT }}` variable
with the value you want to use. 
   * `{{ *-MEM-REQUIRED }}` and `{{ *-CPU-REQUIRED }}` are the minimum amount required to run.
   * `{{ *-MEM-LIMIT }}` and `{{ *-CPU-LIMIT }}` are the maximum allowed values. If the pod goes over `{{ *-MEM-LIMIT }}`, the pod will be terminated.

Here is an example that sets

* Statefulset (manager pods) memory to a starting value of 4Gi to a max of 6Gi.
* Statefulset (manager pods) cpu to a starting value of 2 cores to a max of 4 cores.

   ```bash
   #--------------------------------------------------------------------
   # Statefulset (manager) pod resource configuration
   statefulset-requests-mem=6Gi
   statefulset-limits-mem=8Gi
   statefulset-requests-cpu=2
   statefulset-limits-cpu=4
   
   ```

**Notes:** 

* Only the values you want modified need to be changed.
* For details on the resource value syntax used in the code, see
[Resource units in Kubernetes](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/#resource-units-in-kubernetes).

#### Custom Initial SAS Workload Orchestrator Configuration

The value for the initial SAS Workload Orchestrator configuration 
is in the `configuration.env` file by default as

```bash
# initial-configuration-json={"version":1,"admins":["SASAdministrators"],"hostTypes":[{"name":"default","description":"SAS Workload Orchestrator Server Hosts on Kubernetes Nodes","role":"server"}]}
```

To update the configuration, uncomment the line and modify the JSON.

Here is an example of an initial configuration that adds two additional administrators and sets the max jobs per host in the default host type to 110.

```bash
initial-configuration-json={"version":1,"admins":["SASAdministrators","bob","alice"],"hostTypes":[{"name":"default","description":"SAS Workload Orchestrator Server Hosts on Kubernetes Nodes","role":"server","maxJobsAllowed" : 110}]}
```

**Notes:** 

* The initial configuration is only used if no previous configuration is stored in the database.
* The SAS Workload Orchestrator configuration in JSON can be exported by the Workload Orchestrator
dialog in SAS Environment Manager application or it can be retrieved by using the workload-orchestrator
plugin to the sas-viya CLI.

## User-Defined Scripts Volume for Manager Pods

When a user-defined resource uses a script to return a resource value, 
the filesystem that contains that script needs to be made available to the pod in a location 
specified in the configuration. Mounting a filesystem into the pod requires a volume 
and volumeMount be added to the pod definition. By default, SAS Workload Orchestrator configuration
expects user-defined resource scripts to be the `/scripts` directory and backed by a volume
name `scripts`. An example of patch transformer that mounts an NFS volume as the `scripts` volume
is in the example file `sas-workload-orchestrator-global-user-defined-resources-script-storage.yaml`.

1. Copy the `/$deploy/sas-bases/examples/sas-workload-orchestrator/configure/sas-workload-orchestrator-global-user-defined-resources-script-storage.yaml`
file to your site-config directory as 
`/$deploy/site-config/sas-workload-orchestrator/configure/sas-workload-orchestrator-global-user-defined-resources-script-storage.yaml`.
2. Replace the `{{ NFS-SERVER-ADDR }}` variable with the fully-qualified domain name of the server and 
replace the `{{ NFS-SERVER-PATH }}` variable with the path to the volume on the server. Here is an example:

   ```yaml
     - op: replace
       path: /spec/template/spec/volumes/0
       value:
         name: scripts
         nfs:
           path: /path/to/my/scripts
           server: my.nfs.server.mydomain.com
   ```

Alternately, you could use any other type of volume Kubernetes supports.

The following example updates the volume to use a PersistentVolumeClaim
instead of an NFS mount. This assumes the PVC has already been defined and created.

```yaml
  - op: replace
    path: /spec/template/spec/volumes/0
    value:
      name: scripts
      persistentVolumeClaim:
        claimName: my-pvc-name
        readOnly: true
```

**Note:** For details on the value syntax used specifying volumes, see
[Kubernetes Volumes](https://kubernetes.io/docs/concepts/storage/volumes/).

After you have edited the file, add a reference to it to the transformers
block of the base kustomization.yaml file (`$deploy/kustomization.yaml`). Here is an example:

```yaml
transformers:
...
- site-config/sas-workload-orchestrator/configure/sas-workload-orchestrator-global-user-defined-resources-script-storage.yaml
```