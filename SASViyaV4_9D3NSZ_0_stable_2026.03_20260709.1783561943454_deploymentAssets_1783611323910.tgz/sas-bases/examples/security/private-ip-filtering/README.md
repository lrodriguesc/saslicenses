---
category: security
tocprty: 16
---

# Private IP Filtering

## Overview

By default, SAS Viya platform events are configured to filter out IPs that are
designated to be private. This is to prevent the exposure of internal
infrastructure information to the casual user.

In cases where the filtered IP ranges are needed for auditing, use the process
described in this README to disable the filtering.

## Disabling Private IP Filtering

A kustomize transformer disables the private IP filtering used by SAS Viya
platform events.

Add the `sas-bases/overlays/security/private-ip-filtering/disable.yaml` to the
transformers block in your base kustomization.yaml file.

```yaml
...
transformers:
...
- sas-bases/overlays/security/private-ip-filtering/disable.yaml
...
```

After the base kustomization.yaml file is modified, deploy the software using the commands
that are described in [Deploy the Software](https://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=p127f6y30iimr6n17x2xe9vlt54q.htm).

**Note:** Ensure that the version indicated by the version selector for the
document matches the version of your SAS Viya platform software.
