---
category: security
tocprty: 17
---

# Kubernetes Host System Security Settings

## Overview

Some environments mount the Kubelet root directory or other temporary file system locations with the `noexec` option.
If your environment meets this condition, Java workloads that use the Bouncy Castle FIPS provider might not be able to extract and load the
native library that bcfips uses at runtime. Affected pods can fail to start or can log errors that indicate the
BC FIPS native library could not be installed or loaded. In these environments, the
`$deploy/sas-bases/overlays/security/host-system-security/noexec-tmp-directory.yaml` transformer or the
`$deploy/sas-bases/overlays/security/host-system-security/no-native-bcfips.yaml` transformer
should be applied.

The `noexec-tmp-directory.yaml` transformer configures the Bouncy Castle FIPS provider to use a different directory for
extracting and loading the native library, while the `no-native-bcfips.yaml` transformer configures the Bouncy Castle
FIPS provider to not use the native library at all. The `noexec-tmp-directory.yaml` transformer is the recommended option,
because it allows the Bouncy Castle FIPS provider to use the native library, which can provide better performance.
The `no-native-bcfips.yaml` transformer should only be used if the `noexec-tmp-directory.yaml` transformer does not
resolve the issue in your environment, or if a writable and executable directory is unacceptable in your environment.

## Instructions

To include this transformer in your deployment, add the relative path of the `noexec-tmp-directory.yaml` file
or the `no-native-bcfips.yaml` file
to the `transformers` block of the base kustomization file (`$deploy/kustomization.yaml`).

Here is an example of using the `noexec-tmp-directory.yaml` transformer:

```yaml
...
transformers:
...
- sas-bases/overlays/security/host-system-security/noexec-tmp-directory.yaml
...
```

Here is an example of using the `no-native-bcfips.yaml` transformer:

```yaml
...
transformers:
...
- sas-bases/overlays/security/host-system-security/no-native-bcfips.yaml
...
```
