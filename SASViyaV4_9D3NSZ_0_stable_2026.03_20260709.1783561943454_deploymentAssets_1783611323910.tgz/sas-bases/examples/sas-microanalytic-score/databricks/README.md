---
category: SAS Micro Analytic Service
tocprty: 7
---

# Configure SAS Micro Analytic Service to Enable Access to Databricks

## Overview

This document describes customizations that must be performed by the SAS Viya administrator to enable access to Databricks using Python code as part of SAS Micro Analytic Service. This configuration adds the `databricks-sql-connector` Python package, which allows Python code in SAS Micro Analytic Service to connect to and query Databricks SQL warehouses.

## Prerequisites

**Note:** This document refers to the use of SAS Configurator for Open Source (sas-pyconfig) as an example. If you prefer to configure Python integration without deploying sas-pyconfig, you can instead follow the procedure that is described in [About Provisioning Python for Use with SAS Micro Analytic Service](http://documentation.sas.com/?cdcId=mascdc&cdcVersion=default&docsetId=masag&docsetTarget=p1c4w1v0vsy4mkn19nl9f0uf1rp6.htm) in _SAS Micro Analytic Service: Programming and Administration Guide_. A manual installation of Python in a persistent volume is also supported. Those steps are documented in _Integration with External Languages_.

The SAS Micro Analytic Service Python connector for Databricks requires access to Python. SAS recommends deploying SAS Configurator for Open Source to configure Python integration with the SAS Viya platform, as described in [Configure a Persistent Volume for SAS Configurator for Open Source](https://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyexternlang&docsetTarget=n1vzd0rlkcwu42n1rxcya8h62xez.htm) in _Integration with External Languages_. The connector can then use the distribution in the persistent volume that is bound to the sas-pyconfig PersistentVolumeClaim (PVC).

Perform the following tasks to verify the prerequisites are met:

### Check Status for sas-pyconfig PVC

```sh
kubectl get pvc | grep sas-pyconfig
```

Here is example output:

```
sas-pyconfig                                          Bound    pvc-4b86ea69-e273-4338-820b-656b389a566f   20Gi       RWX            sas-nfs
```

Verify that the STATUS column shows `Bound`. This indicates the PVC is successfully bound to a persistent volume and ready for use.

### Find SAS Micro Analytic Service Pod Names

```sh
kubectl get pods -n <name-of-namespace> | grep sas-microanalytic-score
```

Here is example output:

```
sas-microanalytic-score-cc997bdc8-l42v5                    2/2     Running     0             42h
```

The pod name in the example output is sas-microanalytic-score-cc997bdc8-l42v5. Use this value in the <sas-microanalyticscore-pod-name> variable in subsequent commands.

### Verify python-volume Status

```sh
kubectl describe pod <sas-microanalyticscore-pod-name> -n <name-of-namespace>
```

Here is example output:

```yaml
Volumes:
  python-volume:
    Type:       PersistentVolumeClaim (a reference to a PersistentVolumeClaim in the same namespace)
    ClaimName:  sas-pyconfig
    ReadOnly:   false
```

Verify that a volume named `python-volume` exists with `ClaimName: sas-pyconfig` and `ReadOnly: false`.

## Installation

### Update Python Package Configuration

1. Copy the `$deploy/sas-bases/examples/sas-pyconfig/change-configuration.yaml` file to the `$deploy/site-config/sas-pyconfig` directory.

2. Edit the change-configuration.yaml file and add `databricks-sql-connector` to the list of pip packages:

   ```yaml
   apiVersion: builtin
   kind: PatchTransformer
   metadata:
     name: sas-pyconfig-custom-parameters
   patch: |-
     - op: replace
       path: /data/default_py.pip_install_packages
       value: "<existing_packages> databricks-sql-connector"
   ```

   **Note:** Replace `<existing_packages>` with any packages already configured. If this is the first package being added, you can use just `databricks-sql-connector`. To add multiple packages, separate them with spaces.

   Here is an example using a change-configuration.yaml file with existing packages:

   ```yaml
   value: "Prophet sas_kernel matplotlib sasoptpy sas-esppy NeuralProphet scipy==1.10 Flask XGBoost TensorFlow pybase64 scikit-learn statsmodels sympy mlxtend Skl2onnx nbeats-pytorch ESRNN onnxruntime opencv-python zipfile38 json2 pyenchant nltk spacy gensim pyarrow hnswlib==0.7.0 sas-ipc-queue great-expectations pydantic pandas urllib3 requests saspy swat openai python-dotenv semantic-kernel langchain langchain_openai langchain-core langchain-community testresources tiktoken tabulate azure-identity azure-keyvault-secrets pyodbc sqlalchemy pillow termcolor black databricks-sql-connector"
   ```

### Apply Configuration Changes

Complete one of the following deployment steps to apply the new changes:
   
* **Initial Deployment:** If you are applying the changes during the initial deployment of the SAS Viya platform, complete all the tasks in the README files that you want to use, then see [Deploy the Software](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=p127f6y30iimr6n17x2xe9vlt54q.htm) in _SAS Viya Platform: Deployment Guide_. After the deployment is complete, return to this README to complete the remaining steps.

* **Post-Deployment Updates:** If you are applying the changes after the initial deployment of the SAS Viya platform, see [Modify Existing Customizations in a Deployment](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=n1f2q6pp0gjheqn1jl204vptrubs.htm) in _SAS Viya Platform: Deployment Guide_ for information about how to redeploy the software. After the redeployment is complete, return to this README to complete the remaining steps.

### Run the sas-pyconfig Job

Launch a new instance of the sas-pyconfig job to install the databricks-sql-connector package:

```sh
kubectl create job sas-pyconfig-$(date +%Y%m%d-%H%M%S) --from=cronjob/sas-pyconfig -n <name-of-namespace>
```

**Note:** The command above uses a timestamp as the unique identifier. You can use any unique identifier you prefer.

### Verify Installation

Check the job completion status.

```sh
kubectl get jobs -n <name-of-namespace> | grep sas-pyconfig
```

Here is an example of the expected output:

```
sas-pyconfig-20251212-143052   1/1           45s        2m
```

Wait for the job to show `1/1` in the COMPLETIONS column. This indicates the job has successfully completed and the databricks-sql-connector package has been installed.

## Using Databricks in Python Code

To use Databricks from Python code in SAS Micro Analytic Service, you need the following Databricks credentials:

- **server_hostname** - Your Databricks workspace URL (for example, "your-workspace.cloud.databricks.com")
- **http_path** - The HTTP path of your SQL warehouse (for example, "/sql/1.0/warehouses/your-warehouse-id")
- **access_token** - A personal access token for authentication

The following Python code demonstrates how to connect to Databricks from within your SAS Micro Analytic Service Python code. Include this code in your Python step code or Python model that is executed by SAS Micro Analytic Service:

```python
from databricks import sql

# Replace these values with your actual Databricks credentials
connection = sql.connect(
    server_hostname="your-workspace.cloud.databricks.com",
    http_path="/sql/1.0/warehouses/your-warehouse-id",
    access_token="your-access-token"
)

cursor = connection.cursor()
cursor.execute("SELECT * FROM your_table LIMIT 10")
result = cursor.fetchall()
cursor.close()
connection.close()
```

**Note:** Replace the placeholder values (`your-workspace.cloud.databricks.com`, `/sql/1.0/warehouses/your-warehouse-id`, `your-access-token`, and `your_table`) with your actual Databricks configuration details.
See [Python Support in SAS Micro Analytic Service](https://go.documentation.sas.com/doc/en/mascdc/v_046/masag/p1exphs802pzfgn1jlngr4j4tmw0.htm) for more information on how to add Python code to your models.

## Additional Resources

* [SAS Viya Platform: Deployment Guide](http://documentation.sas.com/?cdcId=itopscdc&cdcVersion=default&docsetId=dplyml0phy0dkr&docsetTarget=titlepage.htm)
* [PersistentVolumeClaims on Kubernetes](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#persistentvolumeclaims)
* [Accessing Analytic Store Model Files](http://documentation.sas.com/?cdcId=sasadmincdc&cdcVersion=default&docsetId=calmodels&docsetTarget=n10916nn7yro46n119nev9sb912c.htm) in _SAS Viya Platform: Models Administration_
* [Configuring Analytic Store and Python Model Directories](http://documentation.sas.com/?cdcId=mascdc&cdcVersion=default&docsetId=masag&docsetTarget=n0er040gsczf7bn1mndiw7znffad.htm) in _SAS Micro Analytic Service: Programming and Administration Guide_
* [Databricks SQL Connector for Python Documentation](https://docs.databricks.com/dev-tools/python-sql-connector.html)